import { NextResponse } from "next/server"
import { v4 as uuidv4 } from "uuid"

// This is a simple in-memory store. In a real application, you'd use a database.
const healthData: { [key: string]: any } = {}

export async function POST(request: Request) {
  const data = await request.json()
  const id = uuidv4()
  healthData[id] = data
  return NextResponse.json({ id })
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get("id")
  if (id && healthData[id]) {
    return NextResponse.json(healthData[id])
  }
  return NextResponse.json({ error: "Data not found" }, { status: 404 })
}

