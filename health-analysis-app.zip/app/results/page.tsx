"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import HealthVisualizations from "@/components/HealthVisualizations"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/components/ui/use-toast"

export default function ResultsPage() {
  const [healthData, setHealthData] = useState(null)
  const [loading, setLoading] = useState(true)
  const searchParams = useSearchParams()

  useEffect(() => {
    const fetchData = async () => {
      const id = searchParams.get("id")
      if (id) {
        try {
          const response = await fetch(`/api/submit-health-data?id=${id}`)
          if (response.ok) {
            const data = await response.json()
            setHealthData(data)
          } else {
            throw new Error("Failed to fetch data")
          }
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to load your health data. Please try again.",
            variant: "destructive",
          })
        } finally {
          setLoading(false)
        }
      }
    }

    fetchData()
  }, [searchParams])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-12 w-3/4 mx-auto mb-8" />
          <Skeleton className="h-[600px] w-full" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-white text-center mb-8">Your Health Analysis</h2>
        <HealthVisualizations data={healthData} />
      </div>
    </div>
  )
}

