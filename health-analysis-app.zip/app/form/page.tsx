"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

export default function HealthForm() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    age: "",
    gender: "",
    weight: "",
    height: "",
    activityLevel: "",
    sleepHours: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({ ...formData, [name]: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/submit-health-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        const data = await response.json()
        router.push(`/results?id=${data.id}`)
      } else {
        throw new Error("Failed to submit data")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit your data. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 flex flex-col items-center justify-center text-white px-4">
      <form onSubmit={handleSubmit} className="w-full max-w-md space-y-6 bg-gray-800 p-8 rounded-xl shadow-lg">
        <h2 className="text-3xl font-bold text-center mb-6">Health Information</h2>

        <div className="space-y-4">
          <div>
            <Label htmlFor="age">Age</Label>
            <Input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={handleChange}
              required
              className="mt-1 text-black"
            />
          </div>

          <div>
            <Label htmlFor="gender">Gender</Label>
            <Select onValueChange={(value) => handleSelectChange("gender", value)}>
              <SelectTrigger className="mt-1 text-black">
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="weight">Weight (kg)</Label>
            <Input
              type="number"
              id="weight"
              name="weight"
              value={formData.weight}
              onChange={handleChange}
              required
              className="mt-1 text-black"
            />
          </div>

          <div>
            <Label htmlFor="height">Height (cm)</Label>
            <Input
              type="number"
              id="height"
              name="height"
              value={formData.height}
              onChange={handleChange}
              required
              className="mt-1 text-black"
            />
          </div>

          <div>
            <Label htmlFor="activityLevel">Activity Level</Label>
            <Select onValueChange={(value) => handleSelectChange("activityLevel", value)}>
              <SelectTrigger className="mt-1 text-black">
                <SelectValue placeholder="Select activity level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentary">Sedentary</SelectItem>
                <SelectItem value="light">Light</SelectItem>
                <SelectItem value="moderate">Moderate</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="very_active">Very Active</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="sleepHours">Average Sleep (hours)</Label>
            <Input
              type="number"
              id="sleepHours"
              name="sleepHours"
              value={formData.sleepHours}
              onChange={handleChange}
              required
              className="mt-1 text-black"
            />
          </div>
        </div>

        <Button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg py-2 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Get Health Analysis
        </Button>
      </form>
    </div>
  )
}

